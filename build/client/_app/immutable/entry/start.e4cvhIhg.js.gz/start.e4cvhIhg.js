import{a as t}from"../chunks/entry.CtbD8SGx.js";export{t as start};
